<?php $__env->startSection('content'); ?>

<div class="container pt-5">
    <div class="row">
        <div class="col-md-10 offset-1">
            <div class="card">
                <div class="card-header bg-dark text-white">
                    <a href="<?php echo e(url('/create')); ?>" class="btn btn-sm btn-outline-success">Create</a>
                    Hello Laravel
                </div>
                <div class="card-body">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                    <?php endif; ?>
                    <table class="table table-striped">
                        <thead>
                            <tr class="text-center">
                                <th>id</th>
                                <th>image</th>
                                <th>name</th>
                                <th>department</th>
                                <th>option</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($i->id); ?></td>
                                <td>
                                    <img src="<?php echo e(asset($i->image)); ?>" width="100px" height="100px" style="border-radius:50px" alt="user-image">
                                </td>
                                <td><?php echo e($i->name); ?></td>
                                <td><?php echo e($i->department); ?></td>
                                <td>
                                    <a href="<?php echo e(url('/edit',$i->id)); ?>" class="btn btn-sm btn-warning">update</a>
                                    <a href="<?php echo e(url('/delete',$i->id)); ?>" class="btn btn-sm btn-danger">delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                        <?php echo e($items->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/sta/Documents/laravel_crud/resources/views/index.blade.php ENDPATH**/ ?>